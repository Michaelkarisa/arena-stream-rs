//! Single source of truth for tunables. Mirrors `com.stream.config.StreamConfig`
//! from the original Java implementation so behavior is comparable during
//! migration testing.

// ── Ports ────────────────────────────────────────────────────────────────
pub const TCP_CONTROL_PORT: u16 = 5000;
pub const UDP_VIDEO_PORT: u16 = 5001;
pub const UDP_AUDIO_PORT: u16 = 5002;

// ── Ingest ───────────────────────────────────────────────────────────────
pub const UDP_RECV_BUFFER_BYTES: usize = 4 * 1024 * 1024;
pub const MAX_AUDIO_FRAME_BYTES: usize = 4096;
pub const AUDIO_SAMPLE_RATE: i32 = 44_100;
pub const AUDIO_CHANNELS: i32 = 1;

// ── Canvas / overlay ─────────────────────────────────────────────────────
pub const CANVAS_W: i32 = 1280;
pub const CANVAS_H: i32 = 720;
/// Overlay render target. **Fixed to equal `CANVAS_W`/`CANVAS_H`**, not a
/// smaller layer that gets scaled up — see `overlay/mod.rs` module docs for
/// why: `LineupWidget`'s own javadoc says "canvas = 1280×720" and computes
/// pixel positions directly against that, with no separate scale factor
/// anywhere in the widget source. Keep these two pairs equal; if they ever
/// need to diverge, every widget's layout math has to be re-derived, not
/// just these two constants.
pub const OVERLAY_W: i32 = CANVAS_W;
pub const OVERLAY_H: i32 = CANVAS_H;
pub const OVERLAY_FPS: i32 = 30;

// ── Encode ───────────────────────────────────────────────────────────────
pub const VIDEO_BITRATE_KBPS: u32 = 2000;
pub const AUDIO_BITRATE_BPS: u32 = 96_000;
pub const KEYFRAME_INTERVAL_FRAMES: u32 = 30;

// ── Transitions ──────────────────────────────────────────────────────────
/// Duration of a crossfade / resize / reposition animation (ms). Applies to
/// scene-switch transitions and live ad-space resize/reposition alike —
/// both are just interpolated GObject property changes on compositor pads.
pub const TRANSITION_MS: u64 = 400;

// ── Fallback ─────────────────────────────────────────────────────────────
/// If no buffer has arrived on the live video pad within this window,
/// crossfade to the fallback source.
pub const FALLBACK_TIMEOUT_MS: u64 = 4_000;

// ── Health / cleanup ─────────────────────────────────────────────────────
pub const INACTIVITY_CLEANUP_MS: u64 = 900_000; // 15 min
pub const METRICS_REPORT_INTERVAL_MS: u64 = 5_000;

// ── Laravel ("switch6") backend API ─────────────────────────────────────
pub const API_BASE_URL_ENV: &str = "ARENA_API_BASE_URL"; // e.g. https://switch6.example.com
pub const API_TOKEN_ENV: &str = "ARENA_API_TOKEN";
