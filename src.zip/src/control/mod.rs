//! TCP control socket — newline-delimited JSON commands from mobile
//! clients. Mirrors `com.stream.control.ControlSocketHandler`'s dispatch
//! table. Actions: `register`/`start`/`stop`/`switch`/`add_output`/
//! `remove_output`/`remove_camera`/`overlay`/`list_outputs`/`goal`/`card`/
//! `substitute`/`lineup`/`replay`/`replay_end` are fully wired end-to-end
//! (parse payload, mutate `OverlayState` and/or the pipeline, fire-and-
//! forget log via `api::CLIENT`, fan out to other clients).

use crate::api::CLIENT;
use crate::config::TCP_CONTROL_PORT;
use crate::model::{OutputKind, REGISTRY};
use crate::overlay::{LineupState, OverlayState, TeamLineupData};
use crate::pipeline;
use dashmap::DashMap;
use once_cell::sync::Lazy;
use serde_json::{json, Value};
use std::sync::Arc;
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::mpsc::{unbounded_channel, UnboundedSender};
use tracing::{info, warn};

/// Fan-out registry: stream_key -> connected client write-halves.
static FANOUT: Lazy<DashMap<String, Vec<UnboundedSender<String>>>> = Lazy::new(DashMap::new);

/// Overlay state per session, separate from the media-pipeline session so
/// the render loop (`overlay::spawn_overlay_renderer`) can be started
/// independently of pipeline construction.
static OVERLAY_STATES: Lazy<DashMap<String, Arc<OverlayState>>> = Lazy::new(DashMap::new);

/// Accessor for other modules (the ads-management loop) that need to flip
/// overlay flags without owning the control socket's internals.
pub fn overlay_state_for(stream_key: &str) -> Option<Arc<OverlayState>> {
    OVERLAY_STATES.get(stream_key).map(|e| e.value().clone())
}

pub async fn run() -> anyhow::Result<()> {
    let listener = TcpListener::bind(("0.0.0.0", TCP_CONTROL_PORT)).await?;
    info!(port = TCP_CONTROL_PORT, "control socket listening");

    loop {
        let (socket, addr) = listener.accept().await?;
        let peer_ip = addr.ip().to_string();
        tokio::spawn(async move {
            if let Err(e) = handle_connection(socket, peer_ip.clone()).await {
                warn!(peer_ip, "control connection ended: {e}");
            }
        });
    }
}

async fn handle_connection(socket: TcpStream, peer_ip: String) -> anyhow::Result<()> {
    let (read_half, mut write_half) = socket.into_split();
    let mut lines = BufReader::new(read_half).lines();

    let (tx, mut rx) = unbounded_channel::<String>();
    tokio::spawn(async move {
        while let Some(msg) = rx.recv().await {
            if write_half.write_all(msg.as_bytes()).await.is_err() {
                break;
            }
            let _ = write_half.write_all(b"\n").await;
        }
    });

    let mut current_stream_key: Option<String> = None;

    while let Some(line) = lines.next_line().await? {
        if line.trim().is_empty() {
            continue;
        }
        let cmd: Value = match serde_json::from_str(&line) {
            Ok(v) => v,
            Err(e) => {
                warn!(peer_ip, "invalid JSON command: {e}");
                continue;
            }
        };
        let action = cmd.get("action").and_then(Value::as_str).unwrap_or("");
        let stream_key = cmd
            .get("streamKey")
            .and_then(Value::as_str)
            .map(String::from)
            .or_else(|| current_stream_key.clone());

        match action {
            "register" => {
                if let Some(key) = &stream_key {
                    current_stream_key = Some(key.clone());
                    REGISTRY.register_ip(&peer_ip, key);
                    if let Some(session) = REGISTRY.get(key) {
                        session.clients.insert(peer_ip.clone());
                        // Eagerly build this camera's compositor branch so
                        // it's ready for `switch` even before its first
                        // video packet arrives. Best-effort: a session that
                        // hasn't been `start`ed yet has no pipeline to add
                        // to, so this just no-ops via the Err path below —
                        // ingest::udp_video falls back to lazy creation on
                        // first packet regardless.
                        if let Err(e) = pipeline::cameras::add_camera(&session, &peer_ip) {
                            warn!(stream_key = key, peer_ip, "camera branch not pre-built at register: {e}");
                        }
                    }
                    FANOUT.entry(key.clone()).or_default().push(tx.clone());
                    broadcast(key, "list updated");
                    info!(stream_key = key, peer_ip, "client registered");
                }
            }

            "start" => {
                let Some(key) = stream_key.clone() else { continue };
                if REGISTRY.get(&key).is_none() {
                    match pipeline::build_session_pipeline(&key) {
                        Ok(session) => {
                            REGISTRY.put(&key, session.clone());
                            REGISTRY.register_ip(&peer_ip, &key);
                            session.clients.insert(peer_ip.clone());
                            *session.current_streamer.write().unwrap() = Some(peer_ip.clone());
                            // Wire the client that issued `start` in as the
                            // primary camera — see model::CameraInput and
                            // pipeline::cameras module docs. Starts visible
                            // (alpha=1) since it's the only camera so far;
                            // fallback crossfade (alpha=0/1 vs the fallback
                            // pad) still governs actual visibility until
                            // video buffers start flowing.
                            session.cameras.insert(
                                peer_ip.clone(),
                                crate::model::CameraInput::Primary {
                                    appsrc: session.video_appsrc.clone(),
                                    pad: session.live_video_pad.clone(),
                                },
                            );
                            *session.active_camera_ip.write().unwrap() = Some(peer_ip.clone());

                            let overlay_state = Arc::new(OverlayState::default());
                            overlay_state.live.store(true, std::sync::atomic::Ordering::Relaxed);
                            OVERLAY_STATES.insert(key.clone(), overlay_state.clone());
                            crate::overlay::spawn_overlay_renderer(session.clone(), overlay_state);
                            pipeline::transitions::spawn_fallback_monitor(session.clone());
                            crate::ads::spawn_ads_loop(session.clone());

                            // Attach the default RTMP destination if one was
                            // supplied at start time; more outputs (HLS/MP4,
                            // or additional RTMP targets) can be added later
                            // via the `add_output` action without touching
                            // this pipeline.
                            if let Some(url) = cmd.get("rtmpUrl").and_then(Value::as_str) {
                                if let Err(e) =
                                    pipeline::add_output(&session, "default", OutputKind::Rtmp, url)
                                {
                                    warn!(stream_key = key, "failed to add default output: {e}");
                                }
                            }

                            // Awaited (unlike the rest of this client) so we
                            // capture the real Laravel row id for event
                            // logging below — see `StreamSession::laravel_id`
                            // doc comment for why this one call is special.
                            match CLIENT.create_session_awaited(&key, &[]).await {
                                Some(id) => session.laravel_id.store(id, std::sync::atomic::Ordering::Relaxed),
                                None => {
                                    warn!(stream_key = key, "no Laravel session id yet; events will be skipped until a later sync");
                                    // Best-effort fallback: fire-and-forget the
                                    // plain (non-awaited) create call so the
                                    // backend at least learns about this
                                    // session even though we won't have a row
                                    // id to log events against this run.
                                    CLIENT.create_session(&key, &[]);
                                }
                            }
                            CLIENT.update_session_status(&key, "live");
                            broadcast(&key, "started");
                            info!(stream_key = key, "session started");
                        }
                        Err(e) => warn!(stream_key = key, "failed to start session: {e}"),
                    }
                }
            }

            "stop" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(session) = REGISTRY.remove(&key) {
                    pipeline::teardown(&session);
                    OVERLAY_STATES.remove(&key);
                    FANOUT.remove(&key);
                    CLIENT.update_session_status(&key, "finished");
                    broadcast(&key, "stopped");
                    info!(stream_key = key, "session stopped");
                }
            }

            "switch" => {
                // Switch the active streamer: crossfades video via
                // pipeline::cameras::switch_camera (§7.4 fix — this used to
                // only update audio authority) and updates who's
                // audio-authoritative in the same command, since a scene
                // switch implies both in practice.
                if let (Some(key), Some(new_ip)) =
                    (stream_key.clone(), cmd.get("targetIp").and_then(Value::as_str))
                {
                    if let Some(session) = REGISTRY.get(&key) {
                        match pipeline::cameras::switch_camera(&session, new_ip) {
                            Ok(()) => {
                                *session.current_streamer.write().unwrap() = Some(new_ip.to_string());
                                broadcast(&key, &format!("switched:{new_ip}"));
                                info!(stream_key = key, new_ip, "active streamer switched (video crossfaded)");
                            }
                            Err(e) => warn!(stream_key = key, new_ip, "switch failed: {e}"),
                        }
                    }
                }
            }

            "add_output" => {
                let Some(key) = stream_key.clone() else { continue };
                let (Some(id), Some(kind_str), Some(dest)) = (
                    cmd.get("id").and_then(Value::as_str),
                    cmd.get("kind").and_then(Value::as_str),
                    cmd.get("destination").and_then(Value::as_str),
                ) else { continue };
                let kind = match kind_str {
                    "rtmp" => OutputKind::Rtmp,
                    "hls" => OutputKind::Hls,
                    "mp4" => OutputKind::Mp4,
                    other => {
                        warn!("unknown output kind '{other}'");
                        continue;
                    }
                };
                if let Some(session) = REGISTRY.get(&key) {
                    match pipeline::add_output(&session, id, kind, dest) {
                        Ok(()) => broadcast(&key, &format!("output_added:{id}")),
                        Err(e) => warn!(stream_key = key, "add_output failed: {e}"),
                    }
                }
            }

            "remove_output" => {
                let Some(key) = stream_key.clone() else { continue };
                let Some(id) = cmd.get("id").and_then(Value::as_str) else { continue };
                if let Some(session) = REGISTRY.get(&key) {
                    match pipeline::remove_output(&session, id) {
                        Ok(()) => broadcast(&key, &format!("output_removed:{id}")),
                        Err(e) => warn!(stream_key = key, "remove_output failed: {e}"),
                    }
                }
            }

            "resize" => {
                // Live resize/reposition to make room for an image ad.
                let Some(key) = stream_key.clone() else { continue };
                if let Some(session) = REGISTRY.get(&key) {
                    let x = cmd.get("x").and_then(Value::as_i64).unwrap_or(0) as i32;
                    let y = cmd.get("y").and_then(Value::as_i64).unwrap_or(0) as i32;
                    let w = cmd.get("width").and_then(Value::as_i64).unwrap_or(crate::config::CANVAS_W as i64) as i32;
                    let h = cmd.get("height").and_then(Value::as_i64).unwrap_or(crate::config::CANVAS_H as i64) as i32;
                    pipeline::transitions::resize_and_reposition(
                        &session.live_video_pad,
                        x,
                        y,
                        w,
                        h,
                        crate::config::TRANSITION_MS,
                    );
                }
            }

            "state" => {
                // Session lifecycle transition: start/live/ht/et/ft/stopped.
                // Drives which ads are eligible in the ads-management loop.
                let Some(key) = stream_key.clone() else { continue };
                let Some(state_str) = cmd.get("value").and_then(Value::as_str) else { continue };
                let Some(new_state) = crate::model::SessionState::parse(state_str) else {
                    warn!("unknown session state '{state_str}'");
                    continue;
                };
                if let Some(session) = REGISTRY.get(&key) {
                    session.set_state(new_state);
                    if let Some(id) = session.laravel_id() {
                        CLIENT.log_event(id, "state", cmd.clone());
                    } else {
                        warn!(stream_key = key, "state event dropped: no Laravel session id yet");
                    }
                    // `add_goal`'s sibling endpoint for the match record's
                    // own status column — see the "streamKey is the
                    // match_id" note at the top of api/mod.rs. Best-effort:
                    // a non-numeric stream key just skips this, same as
                    // `add_goal` below.
                    if let Some(match_id) = match_id_from_key(&key) {
                        CLIENT.update_match_status(match_id, session_state_status_code(new_state));
                    }
                    // Kick off the "match center" popup (`draw_match_performance_widget`)
                    // whenever play actually starts/resumes — kickoff and
                    // the two restarts (half-time, extra-time) all map to
                    // `Live`, matching how a broadcast would re-announce
                    // "kick off!" each time.
                    if new_state == crate::model::SessionState::Live {
                        if let Some(overlay_state) = OVERLAY_STATES.get(&key) {
                            let mut ms = overlay_state.match_state.write().unwrap();
                            ms.is_active = true;
                            ms.animation_start_time = crate::overlay::graphics::current_time_millis();
                            ms.phase = 0;
                        }
                    }
                    broadcast(&key, &format!("state:{}", new_state.as_str()));
                    info!(stream_key = key, state = new_state.as_str(), "session state changed");
                }
            }

            "replay" => {
                let Some(key) = stream_key.clone() else { continue };
                let rate = cmd.get("speed").and_then(Value::as_f64).unwrap_or(0.5);
                if let Some(session) = REGISTRY.get(&key) {
                    match crate::ads::start_replay(&session, rate) {
                        Ok(()) => broadcast(&key, "replay_started"),
                        Err(e) => warn!(stream_key = key, "replay failed: {e}"),
                    }
                }
            }

            "replay_end" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(session) = REGISTRY.get(&key) {
                    match crate::ads::end_replay(&session) {
                        Ok(()) => broadcast(&key, "replay_ended"),
                        Err(e) => warn!(stream_key = key, "replay_end failed: {e}"),
                    }
                }
            }

            "goal" => {
                let Some(key) = stream_key.clone() else { continue };
                let side = cmd.get("side").and_then(Value::as_str).unwrap_or("home");
                let player = cmd.get("player").and_then(Value::as_str).unwrap_or("Unknown").to_string();
                if let Some(state) = OVERLAY_STATES.get(&key) {
                    let mut ms = state.match_state.write().unwrap();
                    let (team_name, new_score) = if side == "home" {
                        ms.team_a_score += 1;
                        (ms.team_a_name.clone(), ms.team_a_score)
                    } else {
                        ms.team_b_score += 1;
                        (ms.team_b_name.clone(), ms.team_b_score)
                    };
                    drop(ms);
                    *state.goal.write().unwrap() = Some(crate::overlay::graphics::GoalState {
                        is_active: true,
                        animation_start_time: crate::overlay::graphics::current_time_millis(),
                        phase: 0,
                        team_name,
                        player_name: player,
                        new_score,
                    });
                }
                if let Some(id) = REGISTRY.get(&key).and_then(|s| s.laravel_id()) {
                    CLIENT.log_event(id, "goal", cmd.clone());
                } else {
                    warn!(stream_key = key, "goal event dropped: no Laravel session id yet");
                }
                // Dedicated goal-on-the-match-record endpoint, distinct
                // from the generic `log_event` above — see api/mod.rs's
                // "streamKey is the match_id" note.
                if let Some(match_id) = match_id_from_key(&key) {
                    CLIENT.add_goal(match_id, cmd.clone());
                } else {
                    warn!(stream_key = key, "add_goal skipped: stream key is not a numeric match id");
                }
                broadcast(&key, "goal");
            }

            // NOTE: "replay" is intentionally NOT in this arm — it has its
            // own dedicated handler above (ties into `crate::ads::start_replay`).
            // A duplicate "replay" here would be unreachable dead code since
            // Rust match arms are checked in order and the first one above
            // already claims it; caught while writing WORKFLOW.md §7.5.
            "card" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(state) = OVERLAY_STATES.get(&key) {
                    let team_name = cmd.get("team").and_then(Value::as_str).unwrap_or("").to_string();
                    let player_name = cmd.get("player").and_then(Value::as_str).unwrap_or("Unknown").to_string();
                    let reason = cmd.get("reason").and_then(Value::as_str).map(str::to_string);
                    let card_type = match cmd.get("cardType").and_then(Value::as_str) {
                        Some("red") => crate::overlay::graphics::CardType::RedCard,
                        _ => crate::overlay::graphics::CardType::YellowCard,
                    };
                    *state.card.write().unwrap() = Some(crate::overlay::graphics::CardState {
                        is_active: true,
                        animation_start_time: crate::overlay::graphics::current_time_millis(),
                        phase: 0,
                        team_name,
                        player_name,
                        card_type,
                        reason,
                    });
                }
                if let Some(id) = REGISTRY.get(&key).and_then(|s| s.laravel_id()) {
                    CLIENT.log_event(id, "card", cmd.clone());
                } else {
                    warn!(stream_key = key, "card event dropped: no Laravel session id yet");
                }
                broadcast(&key, "card");
            }

            "substitute" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(state) = OVERLAY_STATES.get(&key) {
                    let team_name = cmd.get("team").and_then(Value::as_str).unwrap_or("").to_string();
                    let player_out = cmd.get("playerOut").and_then(Value::as_str).unwrap_or("Unknown").to_string();
                    let player_in = cmd.get("playerIn").and_then(Value::as_str).unwrap_or("Unknown").to_string();
                    *state.substitution.write().unwrap() = Some(crate::overlay::graphics::SubstitutionState {
                        is_active: true,
                        animation_start_time: crate::overlay::graphics::current_time_millis(),
                        phase: 0,
                        team_name,
                        player_out,
                        player_in,
                    });
                }
                if let Some(id) = REGISTRY.get(&key).and_then(|s| s.laravel_id()) {
                    CLIENT.log_event(id, "substitute", cmd.clone());
                } else {
                    warn!(stream_key = key, "substitute event dropped: no Laravel session id yet");
                }
                broadcast(&key, "substitute");
            }

            // `lineup` — pre-kickoff team-sheet sequence. Parses both
            // teams' rosters/benches from the payload and hands them to
            // `OverlayState::lineup`, which `render_frame` then drives
            // through the four-stage sequence (see `LineupState`'s doc
            // comment in overlay/mod.rs).
            "lineup" => {
                if let Some(key) = stream_key.clone() {
                    if let Some(state) = OVERLAY_STATES.get(&key) {
                        match (cmd.get("teamA"), cmd.get("teamB")) {
                            (Some(team_a_val), Some(team_b_val)) => {
                                let (team_a, team_a_subs_table) = parse_team_lineup(team_a_val);
                                let (team_b, team_b_subs_table) = parse_team_lineup(team_b_val);
                                *state.lineup.write().unwrap() = Some(LineupState {
                                    started_at_ms: crate::overlay::graphics::current_time_millis(),
                                    team_a,
                                    team_b,
                                    team_a_subs_table,
                                    team_b_subs_table,
                                });
                            }
                            _ => warn!(stream_key = key, "lineup command missing teamA/teamB payload"),
                        }
                    }
                    if let Some(id) = REGISTRY.get(&key).and_then(|s| s.laravel_id()) {
                        CLIENT.log_event(id, action, cmd.clone());
                    } else {
                        warn!(stream_key = key, action, "event dropped: no Laravel session id yet");
                    }
                    broadcast(&key, action);
                }
            }

            // Live on/off switch for the whole overlay compositor pad —
            // animates `overlay_pad`'s alpha the same way the camera
            // fallback crossfade does (see pipeline::transitions). Payload:
            // {"action":"overlay","value":"on"|"off"}.
            "overlay" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(session) = REGISTRY.get(&key) {
                    let show = cmd.get("value").and_then(Value::as_str) != Some("off");
                    pipeline::transitions::animate_f64(
                        &session.overlay_pad,
                        "alpha",
                        if show { 1.0 } else { 0.0 },
                        crate::config::TRANSITION_MS,
                    );
                    broadcast(&key, if show { "overlay:on" } else { "overlay:off" });
                }
            }

            // Tears down one camera's compositor branch and forgets its
            // IP -> stream-key mapping. Complements `register`'s
            // `add_camera` — see pipeline::cameras::remove_camera's doc
            // comment, which anticipated exactly this action.
            "remove_camera" => {
                let Some(key) = stream_key.clone() else { continue };
                let target_ip = cmd.get("ip").and_then(Value::as_str).unwrap_or(&peer_ip).to_string();
                if let Some(session) = REGISTRY.get(&key) {
                    match pipeline::cameras::remove_camera(&session, &target_ip) {
                        Ok(()) => {
                            REGISTRY.unregister_ip(&target_ip);
                            session.clients.remove(&target_ip);
                            broadcast(&key, "list updated");
                            info!(stream_key = key, ip = target_ip, "camera removed");
                        }
                        Err(e) => warn!(stream_key = key, ip = target_ip, "remove_camera failed: {e}"),
                    }
                }
            }

            // Diagnostic/UI-population action: reports each active output
            // branch's id and kind back to the requesting client only
            // (not broadcast — this is per-connection state, not a
            // session-wide event).
            "list_outputs" => {
                let Some(key) = stream_key.clone() else { continue };
                if let Some(session) = REGISTRY.get(&key) {
                    let outputs: Vec<Value> = session
                        .output_branches
                        .iter()
                        .map(|entry| json!({ "id": entry.value().id, "kind": format!("{:?}", entry.value().kind) }))
                        .collect();
                    let _ = tx.send(json!({ "message": "outputs", "outputs": outputs }).to_string());
                }
            }

            other => warn!(peer_ip, "unknown control action '{other}'"),
        }
    }

    Ok(())
}

/// Builds one team's `TeamLineupData` (starting XI) and paired
/// `SubstitutionTable` (bench) from a `lineup` command's `teamA`/`teamB`
/// payload object. `is_active` on the returned table starts `false` —
/// `render_frame` flips it (and stamps `animation_start_time`) itself, the
/// first frame that team's subs-table stage is actually reached; see
/// `LineupState`'s doc comment for why.
fn parse_team_lineup(team: &Value) -> (TeamLineupData, crate::overlay::graphics::SubstitutionTable) {
    let team_name = team.get("name").and_then(Value::as_str).unwrap_or("").to_string();
    let formation = team.get("formation").and_then(Value::as_str).unwrap_or("4-4-2").to_string();
    let jersey_color = team.get("jerseyColor").and_then(Value::as_u64).unwrap_or(0) as u32;

    let players: Vec<std::collections::HashMap<String, String>> = team
        .get("players")
        .and_then(Value::as_array)
        .map(|arr| {
            arr.iter()
                .map(|p| {
                    let mut map = std::collections::HashMap::new();
                    map.insert("team".to_string(), team_name.clone());
                    map.insert("name".to_string(), p.get("name").and_then(Value::as_str).unwrap_or("").to_string());
                    map.insert("number".to_string(), p.get("number").map(value_to_display_string).unwrap_or_default());
                    map.insert("position".to_string(), p.get("position").and_then(Value::as_str).unwrap_or("").to_string());
                    map
                })
                .collect::<Vec<std::collections::HashMap<String, String>>>()
        })
        .unwrap_or_default();

    let substitutes: Vec<crate::overlay::graphics::SubstitutePlayer> = team
        .get("subs")
        .and_then(Value::as_array)
        .map(|arr| {
            arr.iter()
                .map(|p| crate::overlay::graphics::SubstitutePlayer {
                    name: p.get("name").and_then(Value::as_str).unwrap_or("").to_string(),
                    jersey_number: p.get("number").and_then(Value::as_i64).unwrap_or(0) as i32,
                    position: p.get("position").and_then(Value::as_str).unwrap_or("").to_string(),
                    is_goalkeeper: p.get("goalkeeper").and_then(Value::as_bool).unwrap_or(false),
                })
                .collect::<Vec<crate::overlay::graphics::SubstitutePlayer>>()
        })
        .unwrap_or_default();

    let subs_table = crate::overlay::graphics::SubstitutionTable {
        is_active: false,
        animation_start_time: 0,
        phase: 0,
        team_name: team_name.clone(),
        team_color: jersey_color,
        substitutes,
    };

    (TeamLineupData { players, formation, jersey_color }, subs_table)
}

/// `players[].number` is commonly sent as either a JSON string or a
/// number depending on the mobile client; normalize either to a display
/// string rather than dropping non-string values.
fn value_to_display_string(v: &Value) -> String {
    match v {
        Value::String(s) => s.clone(),
        other => other.to_string(),
    }
}

/// Per the "streamKey is the match_id" note at the top of api/mod.rs: the
/// Laravel `matches` table id is the stream key itself, numeric. Returns
/// `None` (rather than guessing) for any stream key that isn't purely
/// numeric, so callers can skip the match-record-specific API calls
/// without sending a bogus id.
fn match_id_from_key(key: &str) -> Option<i64> {
    key.parse::<i64>().ok()
}

/// Maps `SessionState` to the small integer status code the Laravel
/// `matches.status` column uses. Kept local to the control socket (rather
/// than on `SessionState` itself) since it's purely an API-wire concern.
fn session_state_status_code(state: crate::model::SessionState) -> i32 {
    use crate::model::SessionState::*;
    match state {
        Start => 0,
        Live => 1,
        HalfTime => 2,
        ExtraTime => 3,
        FullTime => 4,
        Stopped => 5,
    }
}

fn broadcast(stream_key: &str, message: &str) {
    if let Some(mut senders) = FANOUT.get_mut(stream_key) {
        let payload = json!({ "message": message }).to_string();
        senders.retain(|tx| tx.send(payload.clone()).is_ok());
    }
}
