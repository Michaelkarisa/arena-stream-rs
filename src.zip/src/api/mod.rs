//! Client for the Laravel backend ("switch6"). Mirrors
//! `com.stream.api.ApiClient`: fire-and-forget writes with exponential
//! backoff, never blocking the media/control path. Talks to the routes
//! defined in `stream_routes.php` (GET/POST/PUT/DELETE, not namespaced
//! under `/api` per the earlier instruction).


//streamkey is the match_id. 
//from the matchdata sent by the user the matchdata.id from the match is == to streamkey.
use once_cell::sync::Lazy;
use serde::Serialize;
use serde_json::json;
use std::time::Duration;
use tracing::warn;

pub static CLIENT: Lazy<ApiClient> = Lazy::new(ApiClient::from_env);

const RETRY_DELAYS_MS: [u64; 4] = [500, 1_000, 2_000, 4_000];

pub struct ApiClient {
    http: reqwest::Client,
    base_url: String,
    token: Option<String>,
}

impl ApiClient {
    fn from_env() -> Self {
        let base_url = std::env::var(crate::config::API_BASE_URL_ENV)
            .unwrap_or_else(|_| "http://localhost:8000".to_string());
        let token = std::env::var(crate::config::API_TOKEN_ENV).ok();
        Self {
            http: reqwest::Client::builder()
                .timeout(Duration::from_secs(5))
                .build()
                .expect("failed to build reqwest client"),
            base_url,
            token,
        }
    }

    fn request(&self, method: reqwest::Method, path: &str) -> reqwest::RequestBuilder {
        let url = format!("{}{}", self.base_url, path);
        let mut req = self.http.request(method, url);
        if let Some(token) = &self.token {
            req = req.bearer_auth(token);
        }
        req
    }

    /// Fire-and-forget POST/PUT with retry-with-backoff, spawned onto its
    /// own task so callers (control socket, ingest) never block on it.
    fn dispatch(&self, method: reqwest::Method, path: String, body: serde_json::Value) {
        let req_base = self.request(method.clone(), &path);
        let http = self.http.clone();
        let base_url = self.base_url.clone();
        let token = self.token.clone();
        drop(req_base);

        tokio::spawn(async move {
            for (attempt, delay_ms) in std::iter::once(0)
                .chain(RETRY_DELAYS_MS.iter().copied())
                .enumerate()
            {
                if attempt > 0 {
                    tokio::time::sleep(Duration::from_millis(delay_ms)).await;
                }
                let url = format!("{base_url}{path}");
                let mut req = http.request(method.clone(), &url).json(&body);
                if let Some(t) = &token {
                    req = req.bearer_auth(t);
                }
                match req.send().await {
                    Ok(resp) if resp.status().is_success() => return,
                    Ok(resp) => warn!(url, status = %resp.status(), "api call non-2xx"),
                    Err(e) => warn!(url, "api call error: {e}"),
                }
            }
            warn!(path, "api call exhausted retries, giving up");
        });
    }

    pub fn create_session(&self, stream_key: &str, targets: &[String]) {
        self.dispatch(
            reqwest::Method::POST,
            "/stream-sessions".into(),
            json!({ "stream_key": stream_key, "status": "live", "platform_targets": targets }),
        );
    }

    /// Awaited variant of `create_session` — needed once, at session start,
    /// specifically to capture the Laravel-assigned row id so later
    /// `log_event` calls can reference the real session instead of a
    /// placeholder. Everything else in this client stays fire-and-forget;
    /// this is the one exception, and it only runs once per session.
    pub async fn create_session_awaited(&self, stream_key: &str, targets: &[String]) -> Option<i64> {
        let body = json!({ "stream_key": stream_key, "status": "live", "platform_targets": targets });
        for (attempt, delay_ms) in std::iter::once(0).chain(RETRY_DELAYS_MS.iter().copied()).enumerate() {
            if attempt > 0 {
                tokio::time::sleep(Duration::from_millis(delay_ms)).await;
            }
            let resp = match self.request(reqwest::Method::POST, "/stream-sessions").json(&body).send().await {
                Ok(r) if r.status().is_success() => r,
                Ok(r) => {
                    warn!(status = %r.status(), "create_session_awaited: non-2xx");
                    continue;
                }
                Err(e) => {
                    warn!("create_session_awaited: request error: {e}");
                    continue;
                }
            };
            match resp.json::<serde_json::Value>().await {
                Ok(v) => {
                    if let Some(id) = v.get("id").and_then(serde_json::Value::as_i64) {
                        return Some(id);
                    }
                    warn!("create_session_awaited: response had no integer 'id' field");
                    return None;
                }
                Err(e) => {
                    warn!("create_session_awaited: failed to parse response JSON: {e}");
                    return None;
                }
            }
        }
        warn!(stream_key, "create_session_awaited: exhausted retries, giving up");
        None
    }

    pub fn update_session_status(&self, stream_key: &str, status: &str) {
        self.dispatch(
            reqwest::Method::PUT,
            format!("/stream-sessions/{stream_key}"),
            json!({ "status": status }),
        );
    }

    pub fn log_event(&self, session_id: i64, event_type: &str, payload: serde_json::Value) {
        self.dispatch(
            reqwest::Method::POST,
            "/stream-events".into(),
            json!({ "session_id": session_id, "type": event_type, "payload": payload }),
        );
    }

    pub fn report_views(
        &self,
        session_id: i64,
        stream_key: &str,
        platform: &str,
        view_count: u64,
    ) {
        self.dispatch(
            reqwest::Method::POST,
            "/stream-views".into(),
            json!({
                "session_id": session_id,
                "stream_key": stream_key,
                "platform": platform,
                "view_count": view_count,
            }),
        );
    }

    pub fn award_rank_points(&self, broadcaster_id: i64, current_views: u64) {
        self.dispatch(
            reqwest::Method::POST,
            format!("/broadcaster-rank/{broadcaster_id}/award"),
            json!({ "current_views": current_views }),
        );
    }

    pub fn add_goal(&self, match_id: i64, goal_data: serde_json::Value) {
        self.dispatch(
            reqwest::Method::POST,
            format!("/matches/{match_id}/add-goal"),
            goal_data,
        );
    }

    pub fn update_match_status(&self, match_id:i64, status:i32) {
        self.dispatch(reqwest::Method::POST, format!("/matches/{match_id}/status"), 
        json!({"status":status}));
    }

    pub fn get_ads(&self) {
        self.dispatch(
            reqwest::Method::GET,
            format!("ads"),
            json!({}));
    }
}



#[derive(Serialize)]
pub struct ViewTotals {
    pub stream_key: String,
    pub total_views: u64,
}
