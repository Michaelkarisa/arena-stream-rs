use dashmap::{DashMap, DashSet};
use gstreamer as gst;
use gstreamer::prelude::*;
use gstreamer_app as gst_app;
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::RwLock;
use std::time::{SystemTime, UNIX_EPOCH};

/// One dynamically-added output branch (HLS / RTMP / MP4) hanging off the
/// shared `tee`. Kept so we can cleanly remove it later without tearing
/// down the rest of the live pipeline.
pub struct OutputBranch {
    pub id: String,
    pub kind: OutputKind,
    /// The video tee's request pad feeding this branch.
    pub video_tee_pad: gst::Pad,
    /// The audio tee's request pad feeding this branch.
    pub audio_tee_pad: gst::Pad,
    /// The bin containing this branch's queue/encoder/mux/sink chain —
    /// added to the pipeline as a single unit so teardown is one call.
    pub bin: gst::Bin,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OutputKind {
    Rtmp,
    Hls,
    Mp4,
}

/// One camera-operator's video input, wired into its own `compositor` sink
/// pad so `switch` can crossfade between cameras exactly like
/// fallback/ad transitions do. `Primary` is the camera wired in at
/// pipeline-build time (the one whose `start` command actually created the
/// session); `Dynamic` ones are additional cameras added later via
/// `pipeline::cameras::add_camera`, each with its own decode bin.
pub enum CameraInput {
    Primary {
        appsrc: gst_app::AppSrc,
        pad: gst::Pad,
    },
    Dynamic {
        appsrc: gst_app::AppSrc,
        pad: gst::Pad,
        bin: gst::Bin,
    },
}

impl CameraInput {
    pub fn appsrc(&self) -> &gst_app::AppSrc {
        match self {
            Self::Primary { appsrc, .. } | Self::Dynamic { appsrc, .. } => appsrc,
        }
    }

    pub fn pad(&self) -> &gst::Pad {
        match self {
            Self::Primary { pad, .. } | Self::Dynamic { pad, .. } => pad,
        }
    }
}

/// Lifecycle state of a session/match, as tracked by the control socket and
/// consumed by the ads-management loop to decide which ads are eligible.
/// Maps directly to the states named in the ads-management spec:
/// live, start, stopped, ht (half-time), ft (full-time), et (extra time).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum SessionState {
    Start,
    Live,
    HalfTime,
    ExtraTime,
    FullTime,
    Stopped,
}

impl SessionState {
    pub fn parse(s: &str) -> Option<Self> {
        match s.to_ascii_lowercase().as_str() {
            "start" => Some(Self::Start),
            "live" => Some(Self::Live),
            "ht" | "half_time" | "halftime" => Some(Self::HalfTime),
            "et" | "extra_time" | "extratime" => Some(Self::ExtraTime),
            "ft" | "full_time" | "fulltime" => Some(Self::FullTime),
            "stopped" | "stop" => Some(Self::Stopped),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Start => "start",
            Self::Live => "live",
            Self::HalfTime => "ht",
            Self::ExtraTime => "et",
            Self::FullTime => "ft",
            Self::Stopped => "stopped",
        }
    }
}

/// All runtime state for one live stream session. Replaces
/// `com.stream.model.StreamSession` (Java) — same responsibility, different
/// mechanism: instead of owning FFmpeg FIFO handles, this owns a live
/// GStreamer pipeline and the elements needed to reconfigure it in place.
pub struct StreamSession {
    pub stream_key: String,
    pub created_at_ms: i64,
    last_activity_ms: AtomicI64,
    /// Laravel-assigned `stream_sessions.id`, set once at session start
    /// (see `api::create_session_awaited`). `-1` until known — `log_event`
    /// callers should treat that as "not yet available" rather than a real
    /// id, and skip or defer logging rather than send a fake `0`.
    pub laravel_id: AtomicI64,

    pub pipeline: gst::Pipeline,

    // Three inputs (2.1 in the design doc).
    pub video_appsrc: gst_app::AppSrc,
    pub audio_appsrc: gst_app::AppSrc,
    pub overlay_appsrc: gst_app::AppSrc,

    // Compositor sink pads for the live camera input and the fallback loop.
    // Alpha/xpos/ypos/width/height on these pads are what make transitions,
    // resize-for-ad-space, and fallback crossfade all "just property
    // animation" instead of pipeline rebuilds.
    pub live_video_pad: gst::Pad,
    pub fallback_video_pad: gst::Pad,
    pub overlay_pad: gst::Pad,
    /// The main audio appsrc's sink pad on `audiomixer` — captured at build
    /// time so ad/replay audio ducking has something to turn down.
    pub live_audio_pad: gst::Pad,

    pub compositor: gst::Element,
    pub audiomixer: gst::Element,
    /// Tee feeding encoded-video branches (one request pad per output).
    pub video_tee: gst::Element,
    /// Tee feeding encoded-audio branches (one request pad per output).
    pub audio_tee: gst::Element,

    pub output_branches: DashMap<String, OutputBranch>,

    /// Camera-operator client IPs registered to this session (multi-camera
    /// support — same concept as Java's `clients` set).
    pub clients: DashSet<String>,
    pub current_streamer: RwLock<Option<String>>,
    /// One entry per camera-operator IP that has a compositor pad wired in
    /// (the primary one from pipeline build, plus any added dynamically).
    /// `switch` crossfades between these; it does not touch `video_appsrc`/
    /// `live_video_pad` directly anymore except via this map's `Primary`
    /// entry, kept for backward compatibility with the fallback monitor
    /// (§4.3 of WORKFLOW.md), which still watches `live_video_pad`
    /// specifically as "the" live pad regardless of which camera is active.
    pub cameras: DashMap<String, CameraInput>,
    /// Which camera IP is currently visible (alpha≈1) on the live-video
    /// layer. `None` until the first camera's buffers start flowing.
    pub active_camera_ip: RwLock<Option<String>>,
    /// Lifecycle state (start/live/ht/et/ft/stopped) — the ads-management
    /// loop reads this to decide which ads are currently eligible.
    pub state: RwLock<SessionState>,
    /// Set while a video ad is occupying the live-video compositor slot, or
    /// while a replay is in progress — the ads loop and the `replay`
    /// control action check this so they don't stomp on each other.
    pub video_source_busy: std::sync::atomic::AtomicBool,

    last_video_buffer_ms: AtomicI64,
}

impl StreamSession {
    pub fn new(
        stream_key: String,
        pipeline: gst::Pipeline,
        video_appsrc: gst_app::AppSrc,
        audio_appsrc: gst_app::AppSrc,
        overlay_appsrc: gst_app::AppSrc,
        live_video_pad: gst::Pad,
        fallback_video_pad: gst::Pad,
        overlay_pad: gst::Pad,
        live_audio_pad: gst::Pad,
        compositor: gst::Element,
        audiomixer: gst::Element,
        video_tee: gst::Element,
        audio_tee: gst::Element,
    ) -> Self {
        let now = now_ms();
        Self {
            stream_key,
            created_at_ms: now,
            last_activity_ms: AtomicI64::new(now),
            laravel_id: AtomicI64::new(-1),
            pipeline,
            video_appsrc,
            audio_appsrc,
            overlay_appsrc,
            live_video_pad,
            fallback_video_pad,
            overlay_pad,
            live_audio_pad,
            compositor,
            audiomixer,
            video_tee,
            audio_tee,
            output_branches: DashMap::new(),
            clients: DashSet::new(),
            current_streamer: RwLock::new(None),
            cameras: DashMap::new(),
            active_camera_ip: RwLock::new(None),
            state: RwLock::new(SessionState::Start),
            video_source_busy: std::sync::atomic::AtomicBool::new(false),
            last_video_buffer_ms: AtomicI64::new(now),
        }
    }

    pub fn touch(&self) {
        self.last_activity_ms.store(now_ms(), Ordering::Relaxed);
    }

    pub fn last_activity_ms(&self) -> i64 {
        self.last_activity_ms.load(Ordering::Relaxed)
    }

    pub fn mark_video_buffer(&self) {
        self.last_video_buffer_ms.store(now_ms(), Ordering::Relaxed);
    }

    pub fn ms_since_last_video_buffer(&self) -> i64 {
        now_ms() - self.last_video_buffer_ms.load(Ordering::Relaxed)
    }

    pub fn is_current_streamer(&self, ip: &str) -> bool {
        self.current_streamer
            .read()
            .unwrap()
            .as_deref()
            .map(|s| s == ip)
            .unwrap_or(false)
    }

    pub fn state(&self) -> SessionState {
        *self.state.read().unwrap()
    }

    pub fn set_state(&self, s: SessionState) {
        *self.state.write().unwrap() = s;
    }

    /// `None` if the Laravel-side session row hasn't been created yet (the
    /// awaited call in the `start` handler hasn't returned). Callers should
    /// treat `None` as "skip logging this event" rather than substitute a
    /// placeholder id.
    pub fn laravel_id(&self) -> Option<i64> {
        let id = self.laravel_id.load(Ordering::Relaxed);
        if id < 0 {
            None
        } else {
            Some(id)
        }
    }

    pub fn stop(&self) {
        let _ = self.pipeline.set_state(gst::State::Null);
    }
}

pub fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis() as i64
}
